package com.example.demo.core.UseCases;

import com.example.demo.core.driver_ports.iBorrarTarea;

public class BorrarTareaImpl implements iBorrarTarea {

}
