package com.example.demo.core.UseCases;

import com.example.demo.core.driver_ports.iCategoriaTarea;

public class CategoriaTareaImpl implements iCategoriaTarea {

}
