package com.example.demo.core.UseCases;

import com.example.demo.core.driver_ports.iCalendario;

public class VerCalendarioImpl implements iCalendario {

}
