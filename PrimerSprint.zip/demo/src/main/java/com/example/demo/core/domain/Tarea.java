package com.example.demo.core.domain;

public interface Tarea {

}
