package com.example.demo.core.driven_ports;

import com.example.demo.core.domain.Tarea;

public interface TareaRepository extends Tarea {

}
