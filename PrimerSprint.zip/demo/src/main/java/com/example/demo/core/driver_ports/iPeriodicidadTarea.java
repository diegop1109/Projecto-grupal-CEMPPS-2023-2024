package com.example.demo.core.driver_ports;

public interface iPeriodicidadTarea {

}
