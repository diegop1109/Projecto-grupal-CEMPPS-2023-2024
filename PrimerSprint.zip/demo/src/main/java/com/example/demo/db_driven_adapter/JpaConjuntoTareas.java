package com.example.demo.db_driven_adapter;

public class JpaConjuntoTareas {

}
